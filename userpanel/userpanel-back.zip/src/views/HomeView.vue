<template>
	
	
    <!--====== BANNER PART START ======-->

    <section class="banner-area bg_cover d-block d-md-flex align-items-center rcus">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8">
                    <div class="banner-content">
                        <h1 class="title">Welcome to the Trading Platform of the future!</h1>
                        <p>Perfect for traders of all levels, we bring you the future of trading. Join us now and discover limitless possibilities in the financial markets. Welcome to the future of trading!</p>
                        <ul>
                            <li><a class="main-btn" href="#">Whitepaper</a></li>
                            <li><a class="main-btn main-btn-2" href="#">one paper</a></li>
                        </ul>
                        <span>Join us on <a href="#"><i class="fab fa-facebook-square"></i> 21K</a><a href="#"><i
                                    class="fab fa-twitter"></i> 16K</a><a href="#"><i class="fab fa-linkedin"></i>
                                21K</a></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="banner-thumb">
            <img src="/images/alfa/banner-thumb.png" alt="thumb">
        </div>

    </section>

    <!--====== BANNER PART ENDS ======-->

    <!--====== ICO SALE PART START ======-->

    <!-- <section class="ico-sale-area pt-100 pb-100">
        <div class="container">
            <div class="row align-items-end">
                <div class="col-lg-9">
                    <div class="ico-sale-item">
                        <h4 class="title">ICO sale ends in:</h4>
                        <div class="ico-sale-flex d-block d-lg-flex align-items-center">
                            <div class="ico-sale-time">
                                <div id="simple_timer"></div>
                            </div>
                            <div class="ico-sale-raised">
                                <h5 class="title">raised so far:</h5>
                                <ul>
                                    <li><i class="fab fa-ethereum"></i> 689811.59</li>
                                    <li><i class="fab fa-bitcoin"></i> 65549.55</li>
                                    <li><i class="fab fa-btc"></i> 46879.55</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="ico-sale-btns ml-45 text-center mt-30">
                        <a class="main-btn" href="#">join & buy tokens <i class="fal fa-arrow-right"></i></a>
                        <ul>
                            <li><img src="/images/alfa/icon/social-icon-1.png" alt="icon"></li>
                            <li><img src="/images/alfa/icon/social-icon-2.png" alt="icon"></li>
                            <li><img src="/images/alfa/icon/social-icon-3.png" alt="icon"></li>
                            <li><img src="/images/alfa/icon/social-icon-4.png" alt="icon"></li>
                            <li><img src="/images/alfa/icon/social-icon-5.png" alt="icon"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== ICO SALE PART ENDS ======-->

    <!--====== WHO WE ARE PART START ======-->

    <section class="who-we-are-area pt-90 pb-90">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="who-we-are-content text-center">
                        <span class="fsl">who we are?</span>
                        <h3 class="title" style="background-image: linear-gradient(to right, #de4232, #bd1c52, #8a1962, #4e2060, #0d1c4b);">We aim to be the World Bank for the Microeconomy</h3>
                        <p>We are a leading provider of innovative trading solutions, driven by cutting-edge technology and a commitment to empowering traders of all levels. With a focus on transparency, security, and user-friendly interfaces, we offer a platform that revolutionizes the trading experience. Join us and discover the future of trading today.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="who-we-are-thumb pt-80">
                        <img src="/images/alfa/who-we-are-thumb.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="shape">
            <img src="/images/alfa/shape/shape-1.png" alt="shape">
        </div>
    </section>

    <!--====== WHO WE ARE PART ENDS ======-->

    <!--====== BENEFITS PART START ======-->

    <section class="benefits-area pt-140 pb-90">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="benefits-title text-center">
                        <span class="fsl">Our benefits?</span>
                        <h3 class="title" style="background-image: linear-gradient(to right, #de4232, #bd1c52, #8a1962, #4e2060, #0d1c4b);">Why Choose Crypten’s Trading Platform?</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="benefits-item">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="benefits-item-content">
                            <h3 class="title">A Secure Platform for ICO and Cryptocurrency Trade</h3>
                            <p>Join our secure platform for ICO and cryptocurrency trade. With robust security measures, verified ICO listings, and a user-friendly interface, we provide a trusted environment for trading digital assets.</p>
                            <p class="text"> Explore the world of blockchain innovation with confidence and seize profitable opportunities. Experience secure and hassle-free trading today.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="benefits-thumb-1">
                <img src="/images/alfa/benefits-1.png" alt="benefits">
            </div>
        </div>
        <div class="benefits-item item-2">
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-lg-5">
                        <div class="benefits-item-content">
                            <h3 class="title">Generating Secure and Adaptive Smart Contracts</h3>
                            <p>Experience the power of secure and adaptive smart contracts on our platform. With advanced security measures and a focus on adaptability, we ensure the integrity and flexibility of your contracts. </p>
                            <p class="text"> Trust in the automation and efficiency of our smart contracts to streamline your business processes. Join us and unlock the potential of secure and adaptable contract execution.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="benefits-thumb-2">
                <img src="/images/alfa/benefits-2.png" alt="benefits">
            </div>
        </div>
        <div class="benefits-item item-3">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="benefits-item-content">
                            <h3 class="title">Based Around a Global Community Network</h3>
                            <p>Join our platform and be part of a global community network of traders. Connect, collaborate, and learn from like-minded individuals worldwide. Share insights, replicate successful strategies, and access valuable educational resources.</p>
                            <p class="text">Together, let's build a stronger trading community and unlock new opportunities. Join us today and become part of our global network.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="benefits-thumb-1">
                <img src="/images/alfa/benefits-3.png" alt="benefits">
            </div>
        </div>
        <div class="benefits-item item-2">
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-lg-5">
                        <div class="benefits-item-content">
                            <h3 class="title">Scalable, Fast and Ultra Secure Transactions</h3>
                            <p>Scalable, fast, and ultra-secure transactions are at the core of our platform. Experience seamless and efficient transactions with advanced scalability and optimized processes.</p>
                            <p class="text">Enjoy near-instant confirmations and robust security measures for your peace of mind. Join us now and embrace a new level of efficiency in your financial operations.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="benefits-thumb-2">
                <img src="/images/alfa/benefits-4.png" alt="benefits">
            </div>
        </div>
    </section>

    <!--====== BENEFITS PART ENDS ======-->

    <!--====== MARKETPLACE PART START ======-->

    <section class="marketplace-area pt-180 pb-200">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center">
                        <span >Marketplace issues?</span>
                        <h3 class="title">Problems In Global Marketplace And Our Solutions</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-7 order-lg-0 order-0">
                    <div class="marketplace-item mt-30">
                        <span>01.</span>
                        <img src="/images/alfa/icon/icon-1.png" alt="icon">
                        <h3 class="title">Centralized <br> Platform</h3>
                        <p>Trade multiple assets, access real-time data, and manage your portfolio seamlessly on our centralized platform. Benefit from a simplified trading experience, robust security measures, and a supportive community.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 order-lg-1 order-2">
                    <div class="marketplace-item mt-30">
                        <span>02.</span>
                        <img src="/images/alfa/icon/icon-2.png" alt="icon">
                        <h3 class="title">No Crowd <br> Wisdom </h3>
                        <p>Embrace your individual expertise on our platform. We value independent thinking and empower traders to trust their own judgment. Access comprehensive data, advanced tools, and personalize your strategies.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 order-lg-2 order-4">
                    <div class="marketplace-item mt-30">
                        <span>03.</span>
                        <img src="/images/alfa/icon/icon-3.png" alt="icon">
                        <h3 class="title">No Rewards <br> Mechanism</h3>
                        <p>Experience a fair and unbiased trading environment on our platform, free from external rewards. We prioritize genuine analysis and individual aspirations. Embrace a culture of responsible trading and personal growth.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 order-lg-3 order-1">
                    <div class="marketplace-item item-2 mt-15">
                        <span>Solution.</span>
                        <img src="/images/alfa/icon/icon-4.png" alt="icon">
                        <h3 class="title">Decentralized <br> Platform</h3>
                        <p>Trust and transparency thrive as data is distributed across a network of nodes. Verify transactions independently, reduce costs by eliminating intermediaries, and unlock innovative possibilities through decentralized applications.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 order-lg-4 order-3">
                    <div class="marketplace-item item-2 mt-15">
                        <span>Solution.</span>
                        <img src="/images/alfa/icon/icon-5.png" alt="icon">
                        <h3 class="title">Crowd <br> Platform</h3>
                        <p>Where diverse minds converge to harness the power of collective intelligence. In dynamic community, contribute your insights, and collaborate with others to drive innovation and make informed decisions.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 order-lg-5 order-5">
                    <div class="marketplace-item item-2 mt-15">
                        <span>Solution.</span>
                        <img src="/images/alfa/icon/icon-6.png" alt="icon">
                        <h3 class="title">Our Rewards <br> Mechanism</h3>
                        <p> We recognize and incentivize achievements through our fair and transparent rewards mechanism. Engage, contribute, for your valuable efforts to build a community where success is acknowledged and rewarded.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="marketplace-btn text-center">
                        <ul>
                            <li><a class="main-btn" href="#">whitepaper</a></li>
                            <li><a class="main-btn main-btn-2" href="#">one paper</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== MARKETPLACE PART ENDS ======-->

    <!--====== TOKEN PART START ======-->

    <section class="token-area">
        <div class="container">
            <div class="token-border">
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="section-title text-center">
                            <span>our token distribution</span>
                            <h3 class="title">Token Allocation Forecast</h3>
                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home"
                                        role="tab" aria-controls="pills-home" aria-selected="true">allocation</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile"
                                        role="tab" aria-controls="pills-profile" aria-selected="false">distribution</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                aria-labelledby="pills-home-tab">
                                <div class="token-thumb">
                                    <img src="/images/alfa/token-item.png" alt="">
                                </div>
                                <div class="token-content-list">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6">
                                            <div class="list d-flex">
                                                <ul>
                                                    <li>Product Develoment</li>
                                                    <li>Marketing</li>
                                                    <li>Business Development</li>
                                                    <li>Legal & Regulation</li>
                                                </ul>
                                                <ul class="item">
                                                    <li><span>30%</span></li>
                                                    <li><span>20%</span></li>
                                                    <li><span>18%</span></li>
                                                    <li><span>14%</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="list item-2 d-flex">
                                                <ul>
                                                    <li>Operational</li>
                                                    <li>Partner/Investor</li>
                                                    <li>Contingency</li>
                                                </ul>
                                                <ul class="item">
                                                    <li><span>08%</span></li>
                                                    <li><span>06%</span></li>
                                                    <li><span>04%</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                aria-labelledby="pills-profile-tab">
                                <div class="token-thumb">
                                    <img src="/images/alfa/token-item.png" alt="">
                                </div>
                                <div class="token-content-list">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6">
                                            <div class="list d-flex">
                                                <ul>
                                                    <li>Product Develoment</li>
                                                    <li>Marketing</li>
                                                    <li>Business Development</li>
                                                    <li>Legal & Regulation</li>
                                                </ul>
                                                <ul class="item">
                                                    <li><span>30%</span></li>
                                                    <li><span>20%</span></li>
                                                    <li><span>18%</span></li>
                                                    <li><span>14%</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="list item-2 d-flex">
                                                <ul>
                                                    <li>Operational</li>
                                                    <li>Partner/Investor</li>
                                                    <li>Contingency</li>
                                                </ul>
                                                <ul class="item">
                                                    <li><span>08%</span></li>
                                                    <li><span>06%</span></li>
                                                    <li><span>04%</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== TOKEN PART ENDS ======-->

    <!--====== CRYPTEN DOCUMENTS PART START ======-->

    <section class="crypten-documents-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="section-title text-center">
                        <span>Crypten documents</span>
                        <h3 class="title">Download And Read Our Crypto Documents</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="crypten-documents-btns">
                        <ul>
                            <li><a href="#">White Paper <i class="fal fa-download"></i></a></li>
                            <li><a href="#">Tech Paper <i class="fal fa-download"></i></a></li>
                        </ul>
                    </div>
                    <!-- <div class="crypten-documents-btns item-2 mt-10">
                        <ul>
                            <li><a href="#">White Paper <i class="fal fa-download"></i></a></li>
                            <li><a href="#">Tech Paper <i class="fal fa-download"></i></a></li>
                        </ul>
                    </div> -->
                </div>
            </div>
        </div>
        <!-- <div class="crypten-documents-thumb text-center mt-30">
            <img src="/images/alfa/crypten-documents-thumb.jpg" alt="crypten-documents">
        </div> -->
    </section>

    <!--====== CRYPTEN DOCUMENTS PART ENDS ======-->

    <!--====== HOW WORK PART START ======-->

    <!-- <section class="how-work-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="section-title text-center">
                        <span>How does it work?</span>
                        <h3 class="title">Understand Crypten’s Unique Blockchain Ecosystem</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="how-work-item">
                        <ul class="nav nav-pills" id="pills-tab-3" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="pills-1-tab" data-toggle="pill" href="#pills-1"
                                    role="tab" aria-controls="pills-1" aria-selected="true"><img
                                        src="/images/alfa/icon/work-1.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-2-tab" data-toggle="pill" href="#pills-2" role="tab"
                                    aria-controls="pills-2" aria-selected="false"><img
                                        src="/images/alfa/icon/work-2.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-3-tab" data-toggle="pill" href="#pills-3" role="tab"
                                    aria-controls="pills-3" aria-selected="false"><img
                                        src="/images/alfa/icon/work-3.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-4-tab" data-toggle="pill" href="#pills-4" role="tab"
                                    aria-controls="pills-4" aria-selected="false"><img
                                        src="/images/alfa/icon/work-4.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-5-tab" data-toggle="pill" href="#pills-5" role="tab"
                                    aria-controls="pills-5" aria-selected="false"><img
                                        src="/images/alfa/icon/work-5.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-6-tab" data-toggle="pill" href="#pills-6" role="tab"
                                    aria-controls="pills-6" aria-selected="false"><img
                                        src="/images/alfa/icon/work-6.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-7-tab" data-toggle="pill" href="#pills-7" role="tab"
                                    aria-controls="pills-7" aria-selected="false"><img
                                        src="/images/alfa/icon/work-7.png" alt="work"></a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-8-tab" data-toggle="pill" href="#pills-8" role="tab"
                                    aria-controls="pills-8" aria-selected="false"><img
                                        src="/images/alfa/icon/work-8.png" alt="work"></a>
                            </li>
                        </ul>
                        <div class="how-work-thumb">
                            <img src="/images/alfa/how-work-thumb.png" alt="work">
                        </div>
                        <div class="tab-content" id="pills-tabContent-3">
                            <div class="tab-pane fade show active" id="pills-1" role="tabpanel"
                                aria-labelledby="pills-1-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">01. Consumer</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-2" role="tabpanel" aria-labelledby="pills-2-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">02. Market</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-3" role="tabpanel" aria-labelledby="pills-3-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">03. Support</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-4" role="tabpanel" aria-labelledby="pills-4-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">04. Mobile App</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-5" role="tabpanel" aria-labelledby="pills-5-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">05. Marketing</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-6" role="tabpanel" aria-labelledby="pills-6-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">06. Web Development</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-7" role="tabpanel" aria-labelledby="pills-7-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">07. Competitors</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-8" role="tabpanel" aria-labelledby="pills-8-tab">

                                <div class="how-work-content">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-6">
                                            <div class="how-work-content-item text-center">
                                                <h4 class="title">08. Hosting</h4>
                                                <p>Pellentesque vestibulum fermentum velit non placerat aecnse in
                                                    hendrerit justo uisque quis rhoncus exeget semper semlamat lobortis
                                                    velit ante ipsum primis in faucibus.</p>
                                                <p>Fermentum velit non placerat aecenase in hendrerit justoque quis
                                                    rhoncus exeget semper semlamat lobortis velit.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== HOW WORK PART ENDS ======-->

    <!--====== FUTURE ROADMAP PART START ======-->

    <section class="future-roadmap-area bg_cover  rcus2" >
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title section-title-2 text-center">
                        <span>Future forecast</span>
                        <h3 class="title">Our Future Roadmap</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-md-start justify-content-center first-row">
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2021 Q1</span>
                        <h5 class="title">Concept</h5>
                        <p>Start of the Crypten Platform Development.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2021 Q2</span>
                        <h5 class="title">Research</h5>
                        <p>Research the market for better solutions.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2021 Q3</span>
                        <h5 class="title">Design</h5>
                        <p>Platform design and technical demonstration.</p>
                    </div>
                </div>
            </div>
            <div class="row mt-90 justify-content-center second-row">
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2022 Q3</span>
                        <h5 class="title not-done">Token Sale</h5>
                        <p>Open global sales of Crypten ICO tokens.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2022 Q2</span>
                        <h5 class="title not-done">App Beta Test</h5>
                        <p>App beta launch to public and improvements.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2022 Q1</span>
                        <h5 class="title half-done">Pre-Sale</h5>
                        <p>Public financing and seed funding raised.</p>
                    </div>
                </div>
            </div>
            <div class="row mt-90 justify-content-md-end justify-content-center third-row">
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2023 Q1</span>
                        <h5 class="title not-done">Alfa Launch</h5>
                        <p>Prototype published and linked to Binance blockchain.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2023 Q2</span>
                        <h5 class="title not-done">Community Benefits</h5>
                        <p>Exppand global user base and customer support.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="future-roadmap-item text-center mt-30">
                        <span>2023 Q3</span>
                        <h5 class="title not-done">Hardware things</h5>
                        <p>Integration of third party controllers.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="future-roadmap-thumb">
            <img src="/images/alfa/future-roadmap-thumb.png" alt="thumb">
        </div>
    </section>

    <!--====== FUTURE ROADMAP PART ENDS ======-->

    <!--====== TEAM PART START ======-->

    <!-- <section class="team-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center">
                        <span>Our Senior Management</span>
                        <h3 class="title">Meet Our Executive Team</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-1.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Maria Dokshina</h4>
                            <span>Co-founder, ceo</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-2.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Alexander Nuikin</h4>
                            <span>Project Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-3.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Nadia Cherkasova</h4>
                            <span>Head of Community</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-4.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Bdtayev Valery</h4>
                            <span>PR Director</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-5.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Nikita Shilenko</h4>
                            <span>PR Director</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-6.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Oleg Gaidukov</h4>
                            <span>Technical Officer</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-7.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Bogdan Dupak</h4>
                            <span>Front-end</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-8.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center mt-75 pb-30">
                        <h3 class="title">Meet Our Advisors</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-9.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-10.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-11.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-12.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-13.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-14.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team-item mt-40">
                        <div class="team-thumb">
                            <img src="/images/alfa/team-15.png" alt="team">
                            <div class="team-overlay">
                                <div class="social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Polina Sukhanova</h4>
                            <span>Community Hero</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== TEAM PART ENDS ======-->

    <!--====== FAQ PART START ======-->

    <section class="faq-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center">
                        <span>our Knowledgebase</span>
                        <h3 class="title">Frequently Asked Questions</h3>
                        <ul class="nav nav-pills" id="pills-tab-2" role="tablist">
                           
                           
                        </ul>
                    </div>
                    <div class="tab-content" id="pills-tabContent-2">
                        <div class="tab-pane fade show active" id="pills-a" role="tabpanel"
                            aria-labelledby="pills-a-tab">
                            <div class="faq-accordion">
                                <div class="accrodion-grp" data-grp-name="faq-accrodion">
                                    <div class="accrodion active  animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="0ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>What is SIP-FX Crypto Coin?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>SIP-FX Crypto Coin is a digital cryptocurrency that operates on a decentralized blockchain network. It utilizes cryptographic technology to facilitate secure and transparent transactions.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>
                                    <div class="accrodion   animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="300ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>How does SIP-FX Crypto Coin work?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>SIP-FX Crypto Coin operates on a blockchain network, recording transactions in a decentralized ledger. It uses cryptographic algorithms to secure transactions, validate ownership, and control the creation of new coins. Transactions are verified by network participants known as validators.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>
                                    <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="600ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>How can I acquire SIP-FX Crypto Coins?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>You can acquire SIP-FX Crypto Coins through various means. They can be purchased from cryptocurrency exchanges using traditional currency or other cryptocurrencies. Some coins can also be earned through mining or staking, contributing computing power or holding a certain amount of coins to support the network.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>
                                    <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="600ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>What can I do with SIP-FX Crypto Coins?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>SIP-FX Crypto Coins can be used as a medium of exchange for goods and services, traded on cryptocurrency exchanges for profit, or held as an investment. The specific use cases and functionalities of SIP-FX Crypto Coins may depend on the features and ecosystem of the SIP-FX platform.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>

                                     <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="600ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>Are SIP-FX Crypto Coins secure?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>SIP-FX Crypto Coins leverage cryptographic algorithms and a decentralized network, providing a high level of security. However, it's important to follow best security practices, such as using secure wallets, enabling two-factor authentication, and being cautious of phishing attempts or scams.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>

                                     <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms"
                                        data-wow-delay="600ms">
                                        <div class="accrodion-inner">
                                            <div class="accrodion-title">
                                                <h4>How can I store SIP-FX Crypto Coins?</h4>
                                            </div>
                                            <div class="accrodion-content">
                                                <div class="inner">
                                                    <p>SIP-FX Crypto Coins can be stored in digital wallets. There are different types of wallets, including hardware wallets (physical devices), software wallets (desktop or mobile applications), and online wallets (web-based platforms). It's important to choose a reputable wallet and follow best security practices to keep your SIP-FX Crypto Coins safe.</p>
                                                </div><!-- /.inner -->
                                            </div>
                                        </div><!-- /.accrodion-inner -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== FAQ PART ENDS ======-->

    <!--====== BLOG PART START ======-->

    <!-- <section class="blog-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <span>Our blog</span>
                        <h3 class="title">Fresh Crypten Reads</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="blog-item mt-30">
                        <div class="blog-thumb">
                            <img src="/images/alfa/blog-1.jpg" alt="">
                        </div>
                        <div class="blog-content text-center">
                            <span><span>BLOCKCHAIN</span> | June 19, 2019</span>
                            <a href="#">Decentralized vs. Centralized Exchanges</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="blog-item mt-30">
                        <div class="blog-thumb">
                            <img src="/images/alfa/blog-2.jpg" alt="">
                        </div>
                        <div class="blog-content text-center">
                            <span><span>BLOCKCHAIN</span> | June 19, 2019</span>
                            <a href="#">Cryptocurrencies and The Promising Future</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-sm-9">
                    <div class="blog-item mt-30">
                        <div class="blog-thumb">
                            <img src="/images/alfa/blog-3.jpg" alt="">
                        </div>
                        <div class="blog-content text-center">
                            <span><span>BLOCKCHAIN</span> | June 19, 2019</span>
                            <a href="#">Crypten Blockchain Initiative for 2019</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="blog-btn text-center">
                        <a class="main-btn" href="#">visit our blog <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== BLOG PART ENDS ======-->

    <!--====== BRAND PART START ======-->

    <!-- <section class="brand-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center">
                        <span>Our trusted Partners</span>
                        <h3 class="title">Meet Our Partners and Platform Backers</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/coingeko.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center mt-70">
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="brand-item mt-30">
                        <a href="#"><img src="/images/alfa/brand.png" alt="brand"></a>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!--====== BRAND PART ENDS ======-->

    <!--====== CONTACT PART START ======-->

    <!-- <section class="contact-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center">
                        <span>get in touch with us</span>
                        <h3 class="title">Contact Crypten Today</h3>
                        <p>Have any question? Write to us and we’ll get back to you shortly.</p>
                        <ul>
                            <li><a href="tel:+61383766284"><img src="/images/alfa/icon/icon-7.png" alt="icon"> +61 3
                                    8376 6284</a></li>
                            <li><a href="mailto:info@crypten.com"><img src="/images/alfa/icon/icon-8.png" alt="icon">
                                    info@crypten.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <form action="#">
                        <div class="contact-box">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box mt-10">
                                        <input type="text" placeholder="Name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box mt-10">
                                        <input type="text" placeholder="Email Address">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box mt-10">
                                        <input type="text" placeholder="Phone">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box mt-10">
                                        <input type="text" placeholder="Subject">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box mt-10 text-center">
                                        <textarea name="#" id="#" cols="30" rows="10" placeholder="Message"></textarea>
                                        <button type="submit" class="main-btn">send message <i
                                                class="fal fa-arrow-right"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section> -->


</template>

<script>
	
	export default {
		name: 'AlfaView',
		mounted() {
			document.getElementsByTagName('body')[0].classList.remove('layer');
		},	
		unmounted(){
			document.getElementsByTagName('body')[0].classList.add('layer');
		}					
	}
</script>

<style lang="css" scoped src="../assets/alfa/css/default.css"></style>
<style lang="css" scoped src="../assets/alfa/css/all.css"></style>
<style lang="css" scoped src="../assets/alfa/css/style.css"></style>

<style scoped>

.rcus{
	background-image: url('/images/alfa/banner-bg.png')
}

.rcus2{
	background-image: url('/images/alfa/future-roadmap-bg.png')
}

.fsl {
    font-size:large
}

</style>