<template>
    <form @submit.prevent="withdraw">

        <div class="form_box mb-3">
            <h6 class="text-uppercase mb-0">Available {{ stake_currency?.currency }} :-
                <span>${{ stake_currency?.balance  }}</span>
            </h6>
        </div>

        <div class="form_box mb-3">
            <label class="form-label">Address</label>
            <div class="input-group">
                <input type="text" class="form-control shadow-none" placeholder="Enter Address" v-model="withdraw_address">
            </div>
            <span class="text-danger" style="font-size: var(--fs-14 );" v-if="v$.withdraw_address.$error">
                <div>
                    {{ v$.withdraw_address.$errors[0].$message }}
                </div>
            </span>
        </div>
        <div class="form_box mb-3">
            <label class="form-label">USDT Amount <span>(Min withdrawal = 10 $)</span></label>
            <div class="input-group">
                <input type="text" class="form-control shadow-none" placeholder="Enter Amount" v-model="withdraw_amount"
                    @keypress="this.onHandleKeyPress($event, 8)" @keyup="this.onHandleKeyUp($event, 8)"
                    @keydown="this.onHandleKeyDown($event, 8)" @paste="(e) => e.preventDefault()"
                    @drop="(e) => e.preventDefault()">
            </div>
            <span class="text-danger" style="font-size: var(--fs-14 );" v-if="v$.withdraw_amount.$error">
                <div>
                    {{ v$.withdraw_amount.$errors[0].$message }}
                </div>
            </span>
        </div>
        <div class="mb-3">
            <!-- <h6 class="text-uppercase "> Value :- <span>{{ value }}</span> </h6> -->
            <h6 class="text-uppercase "> After Deduction:- <span>{{ value }}</span> </h6>
            <!-- <h6 class="text-uppercase "> After Deduction :- <span>{{ after_deduction }}</span> </h6> -->
        </div>

        <div class="form_box text-center">
            <button type="button" class="active_btn px-3 py-2" v-if="loading">
                <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                Loading...
            </button>
            <button type="submit" class="active_btn px-3 py-2" v-else>Submit</button>
        </div>
    </form>
</template>
<script>
import ApiClass from "../../api/api.js";
import { required, helpers, minValue } from "@vuelidate/validators";
import { useVuelidate } from "@vuelidate/core";
export default {
    name: "WithdrawToken",
    props: {
        user_wallet: Object,
        callback: Function
    },
    data() {
        return {
            withdraw_address: "",
            withdraw_amount: "",
            loading: false,
            alpha_price: '',
            withdraw_fee: '',
            value: 0,
            after_deduction: 0,
            stake_currency: {},
            default_currency: "USDT",
        }
    },
    setup() {
        return {
            v$: useVuelidate(),
        };
    },
    validations() {
        return {
            withdraw_address: {
                required: helpers.withMessage("Please enter the address.", required)
            },
            withdraw_amount: {
                required: helpers.withMessage('Please enter the amount.', required),
                minValue: helpers.withMessage('Minimun withdrawal is 10 USDT.', minValue(0))
            },
        };
    },
    watch: {
        user_wallet: function (newVal, oldVal) { // watch it
            this.stake_currency = newVal.find((v) => v.currency == this.default_currency) ?? null;


            if (this.stake_currency == null) {

                this.stake_currency = {
                    "currency": "USDT",
                    "balance": "0.00000000"
                }
            }
        },
        withdraw_amount() {
            this.calculatePrice()
        }
    },
    mounted() {
        this.getSetting();
    },
    methods: {
        resetForm() {
            this.withdraw_address = "";
            this.withdraw_amount = "";
            this.v$.$reset(); // reset validation
        },
        async withdraw() {
            const result = await this.v$.$validate();
            if (!result) {
                return;
            }
            this.loading = true;
            var form_data = {
                to_address: this.withdraw_address,
                amount: this.withdraw_amount
            }
            let response = await ApiClass.postRequest("withdraw/i", true, form_data);
            this.loading = false;
            if (response.data.status_code == 0) {
                this.failed(response.data.message)
                return
            }
            if (response.data.status_code == 1) {
                this.success(response.data.message)
                this.resetForm();
                this.callback(); //dashboard refresh
                return;
            }
        },
        calculatePrice() {
            let deduct = this.withdraw_amount * this.withdraw_fee / 100;
            deduct = this.withdraw_amount - deduct;
            this.after_deduction = deduct ;
            this.value = this.withdraw_amount ;
        },
        async getSetting() {
            let response = await ApiClass.getRequest("dashboard/settings", true);
            if (response.data.status_code == 0) {
                return
            }
            if (response.data.status_code == 1) {
                this.alpha_price = response?.data?.data?.alpha_price;
                this.withdraw_fee = response?.data?.data?.withdraw_fee;
                return;
            }
        }
    }

}
</script>
<style></style>